const actorsRoutes = require('./actorsRoutes');
const categoriesRoutes = require('./categoriesRoutes');

module.exports = {
    actorsRoutes,
    categoriesRoutes
};
