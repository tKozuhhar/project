const actorsController = require('./actorsController');
const categoriesController = require('./categoriesController');

module.exports = {
    actorsController,
    categoriesController
};
